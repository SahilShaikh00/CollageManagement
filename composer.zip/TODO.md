# TODO: Fix Login Issues

1. Fix URL case in login.js: Change 'COLLAGEMANAGEMENT' to 'CollageManagement'
2. Update login links in index.php: Change 'login.html' to 'login.php'
3. Update admin index.php: Change redirect to 'login.php', handle roles (admin -> admin page, student -> student page)
4. Hash passwords in api/login.php for signup and login
5. Hash passwords in api/forgetpassword.php for reset
6. Verify student page has session check
