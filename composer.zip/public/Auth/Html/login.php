<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SmartEdu/Login</title>
  <link rel="stylesheet" href="../Css/login.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
  
  

    <div id="messageBox" class="message-box"></div>

  <div class="container">


    <div class="box">
      <div class="slideImage">
        <img src="../../Asset/college-campus.jpg" alt="College Campus"/>
        <div class="image-overlay">
          <h2>Welcome to SmartEdu </h2>
          <p>Streamline your college operations with our comprehensive management system. Access student records, course materials, and administrative tools all in one place.</p>
        </div>
      </div>

      <div class="formSection login-form active">
        <div class="logo">
          <img src="../../Asset/vector-graphic-gold-graduation-hat-academic-college-university-high-school-with-laurel-wreath_771881-231.avif" alt="College Logo"/>
        </div>
        <h2>SmartEdu Login</h2>

        <form id="loginForm">
          <div class="inputGroup">
            <i class="fas fa-envelope"></i>
            <input type="email" placeholder="Email" required/>
          </div>

          <div class="inputGroup">
            <i class="fas fa-lock"></i>
            <input id="passwordInput" type="password" placeholder="Password" required/>
            <i class="fas fa-eye" id="togglePassword"></i>
          </div>
          
          <div class="fgPasssword">
            <a href="#" class="fg-link">Forgot Password?</a>
            <a href="#" class="switch-form" data-form="signup">Create Account</a>
          </div>

          <button type="submit">Login</button>
        </form>       
      </div>

      <div class="formSection signup-form">
        <div class="logo">
          <img src="../../Asset/vector-graphic-gold-graduation-hat-academic-college-university-high-school-with-laurel-wreath_771881-231.avif" alt="College Logo"/>
        </div>
        <h2>Create Your Account</h2>

        <form id="signupForm">
         

          <div class="inputGroup">
            <i class="fas fa-envelope"></i>
            <input type="text" placeholder="Email" required/>
          </div>

          <div class="inputGroup">
            <i class="fas fa-lock"></i>
            <input id="signupPasswordInput" type="password" placeholder="Password" required/>
            <i class="fas fa-eye" id="toggleSignupPassword"></i>
          </div>
          
          <div class="fgPasssword">
            <a href="#" class="switch-form" data-form="login">Already have an account? Login</a>
          </div>

          <button type="submit">Sign Up</button>
        </form>

        
      </div>




      <!-- forget Password  -->
      
<!-- Forgot Password Form -->
<div class="formSection forgot-form">
  <div class="logo">
    <img src="../../Asset/vector-graphic-gold-graduation-hat-academic-college-university-high-school-with-laurel-wreath_771881-231.avif" alt="College Logo"/>
  </div>

      <div class="step-indicator">
                <div class="step active">1</div>
                <div class="step-line"></div>
                <div class="step">2</div>
                <div class="step-line"></div>
                <div class="step">3</div>
            </div>
  <h2>Reset Your Password</h2>

  <!-- Step 1: Email Verification -->
  <div class="forgot-step active" id="forgotStep1">
    
    <form id="forgotEmailForm">
      <div class="inputGroup">
        <i class="fas fa-envelope"></i>
        <input type="email" placeholder="Email Address" required id="forgotEmail"/>
      </div>
      
      <button type="submit">Send Verification Code</button>
    </form>
    
    <div class="fgPasssword">
      <a href="#" class="switch-form" data-form="login"><i class="fas fa-arrow-left"></i> Back to Login</a>
    </div>
  </div>

  <!-- Step 2: OTP Verification -->
  <div class="forgot-step" id="forgotStep2">
    <p class="forgot-instruction">Enter the 6-digit code sent to your email.</p>
    
    <form id="forgotOtpForm">
      <div class="otp-container">
        <input type="text" class="otp-input" maxlength="1" required>
        <input type="text" class="otp-input" maxlength="1" required>
        <input type="text" class="otp-input" maxlength="1" required>
        <input type="text" class="otp-input" maxlength="1" required>
        <input type="text" class="otp-input" maxlength="1" required>
        <input type="text" class="otp-input" maxlength="1" required>
      </div>
      
      <div class="resend-otp">
        Didn't receive the code? <a href="#" id="resend-btn">Resend</a> 
        <span id="timer" class="timer">(02:00)</span>
      </div>
      
      <button type="submit">Verify Code</button>
    </form>
    
    <div class="fgPasssword">
      <a href="#" class="switch-form" data-form="login"><i class="fas fa-arrow-left"></i> Back to Login</a>
    </div>
  </div>

  <!-- Step 3: Password Reset -->
  <div class="forgot-step" id="forgotStep3">
    <p class="forgot-instruction">Create a new password for your account.</p>
    
    <form id="forgotPasswordForm">
      <div class="inputGroup">
        <i class="fas fa-lock"></i>
        <input type="password" placeholder="New Password" required id="newPassword"/>
        <i class="fas fa-eye" id="toggleNewPassword"></i>
      </div>
      
      <div class="password-strength">
        <div class="password-strength-bar" id="password-strength-bar"></div>
      </div>
      <div class="password-strength-text" id="password-strength-text"></div>
      
      <div class="inputGroup">
        <i class="fas fa-lock"></i>
        <input type="password" placeholder="Confirm New Password" required id="confirmPassword"/>
        <i class="fas fa-eye" id="toggleConfirmPassword"></i>
      </div>
      
      <div id="password-match" class="password-match"></div>
      
      <button type="submit">Reset Password</button>
    </form>
    
    <div class="fgPasssword">
      <a href="#" class="switch-form" data-form="login"><i class="fas fa-arrow-left"></i> Back to Login</a>
    </div>
  </div>

  <!-- Success Message -->
  <div class="forgot-step" id="forgotStep4">
    <div class="success-message">
      <i class="fas fa-check-circle"></i>
      <h3>Password Reset Successful!</h3>
      <p>Your password has been successfully reset. You can now login with your new password.</p>
      <button class="switch-form" data-form="login">Go to Login</button>
    </div>
  </div>
</div>

      
  </div>




  <script src="../Script/login.js"></script>
</body>
</html>