<?php
// Set CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Start session
session_start();

// Check if user is logged in via session
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "User not authenticated"
    ]);
    exit;
}

$auth_user = $_SESSION['user'];

http_response_code(200);
echo json_encode([
    "success" => true,
    "message" => "Session is valid",
    "user" => $auth_user
]);
