<?php 

return[
    'jwt_secret' => 'This_is_a_Samrt_Edu_Management_secerete_Key',
    'jwt_algo'   => 'HS256',
    'jwt_exp'   => 43200
];

?>